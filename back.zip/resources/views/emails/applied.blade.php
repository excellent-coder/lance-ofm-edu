<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Request Received</title>
</head>
<body>
    <p>
        Your Application request for {{"$ap->item $ap->applying_for"}}
        has been received and you will be notified once it is reviewed
    </p>
</body>
</html>
