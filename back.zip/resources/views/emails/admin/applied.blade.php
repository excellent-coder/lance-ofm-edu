<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>New {{"$ap->item $ap->applying_for"}} Request</title>
</head>
<body>
<p>
    {{$ap->email}} Applied for {{"$ap->item $ap->applying_for"}} just now
</p>
</body>
</html>
