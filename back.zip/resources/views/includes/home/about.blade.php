<div class="flex flex-wrap justify-center w-full ">
          <div class="w-full text-center lg:w-3/4">
          <h1 class="my-3 text-6xl font-semibold text-center text-black">About</h1>
          {!! $about->description !!}
          </div>
      </div>
