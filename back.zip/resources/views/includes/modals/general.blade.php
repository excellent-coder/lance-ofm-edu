<modal title="Donate to the bank details below" btn-txt="Donate" id="donate-modal">
    <template v-slot:body>
        <div>
            Welcome to our school
            <p>Make a donation to the bank details below</p>
            <p>We sincerly appreciate your donation</p>
        </div>
    </template>
</modal>
<modal id="shop-imgs-modal">
    <template v-slot:body>
        <div>
           <img src="" alt="" id="shop-modal-img">
        </div>
    </template>
</modal>
