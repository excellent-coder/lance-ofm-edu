import Multiselect from './Multiselect.vue'
import multiselectMixin from './multiselectMixin.js'
import pointerMixin from './pointerMixin.js'

export default Multiselect

export {Multiselect, multiselectMixin, pointerMixin}
